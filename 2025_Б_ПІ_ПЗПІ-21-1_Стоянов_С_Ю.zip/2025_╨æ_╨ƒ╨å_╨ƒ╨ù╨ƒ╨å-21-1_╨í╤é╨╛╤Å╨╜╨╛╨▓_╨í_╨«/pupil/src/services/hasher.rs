use anyhow::Context;
use argon2::{
    password_hash::{rand_core::OsRng, PasswordHasher, SaltString},
    Algorithm, Argon2, Params, PasswordVerifier, Version,
};
use secrecy::{ExposeSecret, SecretString};
use serde::Deserialize;

use crate::domain::{
    auth::VerifyPasswordError,
    password::{MaybePassword, Password, PasswordHash},
};

#[derive(Clone, Debug, Deserialize)]
pub struct HasherConfig {
    secret: SecretString,
    #[serde(flatten)]
    params: ArgonParams,
}

#[derive(Clone, Debug, Deserialize)]
pub struct ArgonConfig {}

#[derive(Clone, Debug, Deserialize)]
pub struct ArgonParams {
    memory_size: u32,
    iterations: u32,
    parallelism_factor: u32,
    output_length: Option<usize>,
}

#[derive(Clone)]
pub struct Hasher {
    config: HasherConfig,
}

impl Hasher {
    pub fn new(config: HasherConfig) -> anyhow::Result<Self> {
        let hasher = Self { config };
        let _check_valid = hasher.argon()?;
        Ok(hasher)
    }

    fn argon(&self) -> anyhow::Result<Argon2<'_>> {
        let HasherConfig { secret, params } = &self.config;
        let params = Params::new(
            params.memory_size,
            params.iterations,
            params.parallelism_factor,
            params.output_length,
        )
        .context("validate argon params")?;
        let hasher = Argon2::new_with_secret(
            secret.expose_secret().as_bytes(),
            Algorithm::default(),
            Version::default(),
            params,
        )
        .context("validate argon secret")?;
        Ok(hasher)
    }

    fn expect_argon(&self) -> Argon2<'_> {
        self.argon().expect("valid config")
    }
}

#[tracing::instrument(skip(hasher), ret(level = "debug") err(Debug, level = "debug"))]
pub fn hash_password(hasher: &Hasher, password: &Password) -> crate::Result<PasswordHash> {
    let hash = hasher
        .expect_argon()
        .hash_password(
            password.expose_secret().as_bytes(),
            &SaltString::generate(&mut OsRng),
        )
        .map(|hash| PasswordHash::new(SecretString::from(hash.to_string())))
        .context("hash password")?;
    Ok(hash)
}

#[tracing::instrument(skip(hasher), ret(level = "debug") err(Debug, level = "debug"))]
pub fn verify_password(
    hasher: &Hasher,
    password: MaybePassword,
    password_hash: PasswordHash,
) -> crate::Result<(), VerifyPasswordError> {
    let password_hash = argon2::PasswordHash::new(password_hash.expose_secret())
        .context("parse stored password hash")?;
    hasher
        .expect_argon()
        .verify_password(password.expose_secret().as_bytes(), &password_hash)
        .map_err(|_| crate::Error::expected(VerifyPasswordError::InvalidPassword))
}
