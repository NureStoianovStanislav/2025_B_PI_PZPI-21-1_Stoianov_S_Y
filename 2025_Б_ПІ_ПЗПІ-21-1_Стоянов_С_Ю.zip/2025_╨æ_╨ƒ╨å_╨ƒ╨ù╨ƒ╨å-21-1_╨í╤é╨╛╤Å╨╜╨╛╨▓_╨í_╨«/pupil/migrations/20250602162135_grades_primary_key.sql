-- Modify "grades" table
ALTER TABLE "public"."grades" ADD PRIMARY KEY ("user_id", "subject_id");
