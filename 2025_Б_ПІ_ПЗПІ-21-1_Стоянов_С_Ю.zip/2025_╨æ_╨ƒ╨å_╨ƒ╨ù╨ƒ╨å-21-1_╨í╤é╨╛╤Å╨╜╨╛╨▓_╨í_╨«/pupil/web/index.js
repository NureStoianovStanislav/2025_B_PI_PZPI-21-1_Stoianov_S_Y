import "./index.css";

import "htmx.org";
import "htmx-ext-response-targets";

import "@fontsource/geist-sans";
import "@fontsource-variable/geist-mono";
