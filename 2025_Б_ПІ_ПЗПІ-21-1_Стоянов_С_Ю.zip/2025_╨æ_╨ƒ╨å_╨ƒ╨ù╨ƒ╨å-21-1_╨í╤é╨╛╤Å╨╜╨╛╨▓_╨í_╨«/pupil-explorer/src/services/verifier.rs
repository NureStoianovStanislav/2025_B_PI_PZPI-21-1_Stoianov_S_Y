use std::str::FromStr;

use anyhow::{anyhow, Context};
use ed25519_dalek::{Signature, VerifyingKey};
use serde::Deserialize;
use serde_json_canonicalizer as jcs;

use crate::domain::{
    evaluation::{Evaluation, EvaluationError},
    public_key::PublicKey,
};

#[tracing::instrument(ret(level = "debug") err(Debug, level = "debug"))]
pub async fn evaluate_performance(
    university_key: PublicKey,
    access_key: String,
) -> crate::Result<Evaluation, EvaluationError> {
    let client = reqwest::Client::new();
    let url = format!("http://localhost:8080/performance/{access_key}");
    let eval = match client
        .get(url)
        .send()
        .await
        .context("send an evaluation request")?
        .json()
        .await
        .context("parse output")?
    {
        Response::Success { data } => data,
        Response::Error { data } => {
            let error = match data.error_code.as_str() {
                "UNKNOWN_KEY" => uknown_key(),
                code => crate::Error::internal(anyhow!("{code}").context("university error")),
            };
            return Err(error);
        }
    };
    let claim = jcs::to_vec(&eval.claim).context("encode performance claim as JCS")?;
    let verifying_key = VerifyingKey::from_bytes(&university_key.into())
        .context("convert public key to dalek key")?;
    let signature = Signature::from_str(&eval.signature).map_err(|_| invalid_signature())?;
    verifying_key
        .verify_strict(&claim, &signature)
        .map_err(|_| invalid_signature())?;
    Ok(eval.claim)
}

#[derive(Clone, Debug, Deserialize)]
#[serde(tag = "status", rename_all = "lowercase")]
enum Response {
    Success { data: PerformanceEvaluation },
    Error { data: UniError },
}

#[derive(Clone, Debug, Deserialize)]
struct PerformanceEvaluation {
    claim: Evaluation,
    signature: String,
}

#[derive(Clone, Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
struct UniError {
    error_code: String,
}

fn uknown_key() -> crate::Error<EvaluationError> {
    crate::Error::expected(EvaluationError::UnknownKey)
}

fn invalid_signature() -> crate::Error<EvaluationError> {
    crate::Error::expected(EvaluationError::InvalidSignature)
}
