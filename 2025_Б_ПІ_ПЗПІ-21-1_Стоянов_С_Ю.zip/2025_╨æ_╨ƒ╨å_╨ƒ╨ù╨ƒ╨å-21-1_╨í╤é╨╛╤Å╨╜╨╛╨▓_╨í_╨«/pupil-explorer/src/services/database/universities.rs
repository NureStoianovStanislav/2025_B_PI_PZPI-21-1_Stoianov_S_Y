use crate::domain::universities::University;

use super::{sql_error, Database};

#[tracing::instrument(skip(db), ret(level = "debug") err(Debug, level = "debug"))]
pub async fn get_universities(db: &Database) -> crate::Result<Vec<University>> {
    sqlx::query_as(
        "
        select public_key, name
        from universities
        ",
    )
    .fetch_all(&db.pool)
    .await
    .map_err(sql_error)
}
