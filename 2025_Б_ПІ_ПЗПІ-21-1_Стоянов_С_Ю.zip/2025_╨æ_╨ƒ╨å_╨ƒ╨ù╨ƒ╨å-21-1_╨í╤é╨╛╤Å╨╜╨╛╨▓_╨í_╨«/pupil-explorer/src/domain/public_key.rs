use ed25519_dalek::PUBLIC_KEY_LENGTH;
use educe::Educe;
use serde::{Deserialize, Serialize};

#[derive(Educe, Debug, Clone, sqlx::Type)]
#[educe(Into(KeyBytes))]
#[sqlx(transparent)]
pub struct PublicKey(KeyBytes);

type KeyBytes = [u8; PUBLIC_KEY_LENGTH];

impl Serialize for PublicKey {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        hex::serialize_upper(self.0, serializer)
    }
}

impl<'de> Deserialize<'de> for PublicKey {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        hex::deserialize::<_, Vec<_>>(deserializer)?
            .try_into()
            .map(Self)
            .map_err(|_| serde::de::Error::custom("invalid key length"))
    }
}
