pub mod auth;
pub mod evaluation;
pub mod universities;

pub mod email;
pub mod name;
pub mod password;
pub mod token;
pub mod user_id;

pub mod public_key;
