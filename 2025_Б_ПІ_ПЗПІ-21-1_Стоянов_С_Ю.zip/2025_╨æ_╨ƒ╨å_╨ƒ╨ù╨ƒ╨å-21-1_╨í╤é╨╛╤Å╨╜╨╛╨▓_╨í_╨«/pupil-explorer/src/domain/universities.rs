use serde::Serialize;

use super::public_key::PublicKey;

pub trait GetUniversities {
    async fn get_universities(&self) -> crate::Result<Vec<University>>;
}

#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
#[serde(rename_all = "camelCase")]
pub struct University {
    pub public_key: PublicKey,
    pub name: String,
}
