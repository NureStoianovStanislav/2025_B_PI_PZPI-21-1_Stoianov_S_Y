use serde::{Deserialize, Serialize};

use crate::app::localization::LocalizedError;

use super::public_key::PublicKey;

pub trait EvaluatePerformance {
    async fn evaluate_performance(
        &self,
        university_key: PublicKey,
        access_key: String,
    ) -> crate::Result<Evaluation, EvaluationError>;
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Evaluation {
    pub student: String,
    pub percentile: u8,
}

#[derive(Debug)]
pub enum EvaluationError {
    UnknownKey,
    InvalidSignature,
}

impl From<EvaluationError> for LocalizedError {
    fn from(value: EvaluationError) -> Self {
        match value {
            EvaluationError::UnknownKey => Self::new("UNKNOWN_KEY"),
            EvaluationError::InvalidSignature => Self::new("INVALID_SIGNATURE"),
        }
    }
}
