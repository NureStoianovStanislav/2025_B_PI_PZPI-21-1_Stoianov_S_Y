use crate::{domain::evaluation::*, services::verifier::evaluate_performance};

use super::AppContext;

impl EvaluatePerformance for AppContext {
    async fn evaluate_performance(
        &self,
        university_key: crate::domain::public_key::PublicKey,
        access_key: String,
    ) -> crate::Result<Evaluation, EvaluationError> {
        evaluate_performance(university_key, access_key).await
    }
}
