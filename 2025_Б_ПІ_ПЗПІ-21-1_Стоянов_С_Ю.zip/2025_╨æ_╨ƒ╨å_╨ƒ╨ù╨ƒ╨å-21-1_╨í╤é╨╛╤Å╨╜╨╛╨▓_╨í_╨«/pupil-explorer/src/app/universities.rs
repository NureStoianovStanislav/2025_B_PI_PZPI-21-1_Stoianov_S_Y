use crate::{domain::universities::*, services::database::universities::get_universities};

use super::AppContext;

impl GetUniversities for AppContext {
    async fn get_universities(&self) -> crate::Result<Vec<University>> {
        get_universities(&self.database).await
    }
}
