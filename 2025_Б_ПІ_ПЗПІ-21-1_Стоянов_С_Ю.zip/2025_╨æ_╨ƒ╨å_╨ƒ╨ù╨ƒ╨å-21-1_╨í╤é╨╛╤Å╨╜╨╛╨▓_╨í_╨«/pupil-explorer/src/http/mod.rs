use evaluation::evaluation_routes;
pub use middleware::template::{LocaleNegotiator, TemplateRenderer};

use auth::auth_routes;
use secrecy::{zeroize::Zeroize, ExposeSecret, SecretBox};
use static_files::static_router;
use tower_http::{catch_panic::CatchPanicLayer, trace::TraceLayer};

use std::net::SocketAddr;

use anyhow::Context;
use axum::{extract::State, routing::get, Router};
use middleware::{
    not_found::not_found_view,
    panic::catch_panic,
    template::{Template, TemplateName},
    RouterExt,
};
use serde::{Deserialize, Serialize, Serializer};
use serde_aux::field_attributes::deserialize_number_from_string;
use tokio::net::TcpListener;

use crate::{
    app::AppContext,
    domain::universities::{GetUniversities, University},
    error::Error,
};

mod error;
mod middleware;

mod auth;
mod evaluation;

mod static_files;

#[derive(Clone, Debug, Deserialize)]
pub struct HttpConfig {
    pub host: [u8; 4],
    #[serde(deserialize_with = "deserialize_number_from_string")]
    pub port: u16,
}

pub async fn serve_http(config: HttpConfig, ctx: AppContext) -> anyhow::Result<()> {
    let addr = SocketAddr::from((config.host, config.port));
    let listener = TcpListener::bind(addr).await?;
    let router = root_router()
        .fallback(not_found_view)
        .layer(CatchPanicLayer::custom(catch_panic))
        .with_renderers(ctx.clone())
        .layer(TraceLayer::new_for_http())
        .with_state(ctx)
        .merge(static_router());
    axum::serve(listener, router.into_make_service())
        .await
        .context("start http server")
}

fn root_router() -> Router<AppContext> {
    Router::new()
        .route("/", get(homepage))
        .route(
            "/institutions",
            get(async || Template::new("institutions.html", ())),
        )
        .nest("/auth", auth_routes())
        .nest("/evaluation", evaluation_routes())
}

async fn homepage(
    State(ctx): State<AppContext>,
) -> Result<Template<Vec<University>>, Template<Error>> {
    ctx.get_universities()
        .await
        .map(|universities| Template::new("index.html", universities))
        .map_err(|error| Template::new(TemplateName::error(), error))
}

fn serialize_secret<T, S>(secret: &SecretBox<T>, serializer: S) -> Result<S::Ok, S::Error>
where
    T: Serialize + Zeroize + ?Sized,
    S: Serializer,
{
    secret.expose_secret().serialize(serializer)
}
