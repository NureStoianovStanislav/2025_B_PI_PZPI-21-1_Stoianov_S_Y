use axum::{extract::State, http::StatusCode, routing::get, Form, Router};
use serde::{Deserialize, Serialize};

use crate::{
    app::AppContext,
    domain::{
        evaluation::{EvaluatePerformance, Evaluation, EvaluationError},
        public_key::PublicKey,
    },
    Error,
};

use super::{error::HttpError, middleware::template::Template};

const EVALUATION: &str = "evaluation.html";

pub fn evaluation_routes() -> Router<AppContext> {
    Router::new().route("/", get(evaluate))
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
struct EvaluationRequest {
    university_key: PublicKey,
    access_key: String,
}

async fn evaluate(
    State(ctx): State<AppContext>,
    Form(req): Form<EvaluationRequest>,
) -> Result<Template<Evaluation>, Template<Error<EvaluationError, EvaluationRequest>>> {
    let form = req.clone();
    ctx.evaluate_performance(req.university_key, req.access_key)
        .await
        .map(|eval| Template::new(EVALUATION, eval))
        .map_err(|error| Template::new("index.html", error.with_input(form)))
}

impl HttpError for EvaluationError {
    fn status_code(&self) -> StatusCode {
        match self {
            Self::UnknownKey | Self::InvalidSignature => StatusCode::BAD_REQUEST,
        }
    }
}
