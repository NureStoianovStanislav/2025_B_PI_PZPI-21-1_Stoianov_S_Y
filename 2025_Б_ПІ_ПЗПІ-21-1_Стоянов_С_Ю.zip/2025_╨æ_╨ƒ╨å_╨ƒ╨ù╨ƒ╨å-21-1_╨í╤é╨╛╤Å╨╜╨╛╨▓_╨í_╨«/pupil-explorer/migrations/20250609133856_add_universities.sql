-- Rename a constraint from "users_pkey" to "admins_pkey"
ALTER TABLE "public"."admins" RENAME CONSTRAINT "users_pkey" TO "admins_pkey";
-- Create "universities" table
CREATE TABLE "public"."universities" (
  "public_key" bytea NOT NULL,
  "name" text NOT NULL,
  PRIMARY KEY ("public_key")
);
