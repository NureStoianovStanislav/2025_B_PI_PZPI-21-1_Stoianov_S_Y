-- Rename "users" table
ALTER TABLE "public"."users"
RENAME TO "admins";


-- Rename unique email constraint
ALTER TABLE "public"."admins"
RENAME CONSTRAINT "users_email_key"
TO "admins_email_key";

-- Remove "role" column
ALTER TABLE "public"."admins"
DROP COLUMN "role";
