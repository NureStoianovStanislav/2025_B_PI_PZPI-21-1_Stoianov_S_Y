create table admins (
    id bigserial primary key,
    email text not null unique,
    name text not null,
    password_hash text not null
);

create table universities (
    public_key bytea primary key,
    name text not null
);
